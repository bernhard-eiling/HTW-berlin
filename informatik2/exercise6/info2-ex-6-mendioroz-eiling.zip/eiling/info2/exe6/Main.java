package eiling.info2.exe6;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Stack<String> stack = new Stack<String>();
		
		Postfix post = new Postfix();
		post.readPostfix();
//		String result = post.infixToPostfix("9-4+2");
//		System.out.println(result);
		
		
//		stack.push("dies");
//		stack.push("ein");
//		stack.push("haufen");
//		System.out.println(stack.pop().toString());
//		System.out.println(stack.pop().toString());
//		System.out.println(stack.isEmpty());
//		System.out.println(stack.pop().toString());
//		System.out.println(stack.isEmpty());
//		
	}

}
